# Run this script as Administrator
$ErrorActionPreference = "Stop"

# Define paths based on script location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll64Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x64.dll"
$dll32Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x86.dll"
$logsDir = Join-Path -Path $scriptDir -ChildPath "logs"
$configPath = Join-Path -Path $scriptDir -ChildPath "levo_config.json"

# 1. Verify the DLLs exist
if (-not (Test-Path $dll64Path)) {
    Write-Error "64-bit DLL not found at $dll64Path. Please ensure it exists before continuing."
    exit
}
if (-not (Test-Path $dll32Path)) {
    Write-Error "32-bit DLL not found at $dll32Path. Please ensure it exists before continuing."
    exit
}

# 2. Create logs directory if it doesn't exist
if (-not (Test-Path -Path $logsDir -PathType Container)) {
    New-Item -ItemType Directory -Path $logsDir -Force
    Write-Output "Created logs directory at $logsDir"
}

# 3. Set permissions on the main directory and the logs directory
Write-Output "Setting permissions on $scriptDir and $logsDir..."
# Main directory permissions - with full control
$acl = Get-Acl -Path $scriptDir
$iisRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($iisRule)
Set-Acl -Path $scriptDir -AclObject $acl
Write-Output "Set full control permissions for IIS_IUSRS on main directory"

# Logs directory permissions - with full control
$logAcl = Get-Acl -Path $logsDir
$logRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$logAcl.AddAccessRule($logRule)
Set-Acl -Path $logsDir -AclObject $logAcl
Write-Output "Set full control permissions for IIS_IUSRS on logs directory"

# 4. Import WebAdministration module
Import-Module WebAdministration

# 5. Remove any existing module registrations
if (Get-WebGlobalModule -Name "LevoaiIISModule_x64" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x64"
    Write-Output "Removed existing 64-bit module registration"
}

if (Get-WebGlobalModule -Name "LevoaiIISModule_x86" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x86"
    Write-Output "Removed existing 32-bit module registration"
}

# 6. Register both modules with appropriate preconditions
Write-Output "Registering modules with appropriate preconditions..."

# Register 64-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x64";
    image = $dll64Path;
    preCondition = "bitness64"
}
Write-Output "Registered LevoaiIISModule_x64 as a global module with bitness64 precondition"

# Register 32-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x86";
    image = $dll32Path;
    preCondition = "bitness32"
}
Write-Output "Registered LevoaiIISModule_x86 as a global module with bitness32 precondition"

# 7. Add modules to the global modules collection
if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x64']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x64";
        preCondition = "bitness64"
    }
    Write-Output "Added LevoaiIISModule_x64 to global modules collection"
}

if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x86']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x86";
        preCondition = "bitness32"
    }
    Write-Output "Added LevoaiIISModule_x86 to global modules collection"
}

# 8. Restart IIS to apply changes
Write-Output "Restarting IIS to apply changes..."
iisreset
Write-Output "IIS has been restarted. Module deployment complete."

# 9. Display application pool configurations
Write-Output "`nApplication Pool Configurations:"
Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object {
    $poolName = $_.Name
    $is32Bit = ($_ | Get-ItemProperty).enable32BitAppOnWin64
    $moduleType = if ($is32Bit) { "LevoaiIISModule_x86 (32-bit)" } else { "LevoaiIISModule_x64 (64-bit)" }
    Write-Output "- $poolName`: $moduleType"
}

# 10. Output configuration information
Write-Output "`nDeployment completed with the following configuration:"
Write-Output "64-bit DLL Path: $dll64Path"
Write-Output "32-bit DLL Path: $dll32Path"
Write-Output "Logs Directory: $logsDir"
Write-Output "Config File: $configPath"
# SIG # Begin signature block
# MIIFngYJKoZIhvcNAQcCoIIFjzCCBYsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBap9jR+us1ynGp
# /9ncJenGYYnIblxJQjUxAO3RqsWmkqCCAxAwggMMMIIB9KADAgECAhAw2lzR3mLm
# m0j2qvbW+ZG4MA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNVBAMME0xldm8gU2NyaXB0
# IFNpZ25pbmcwHhcNMjYwNjIzMjEyMzA1WhcNMjkwNjIzMjEzMzA1WjAeMRwwGgYD
# VQQDDBNMZXZvIFNjcmlwdCBTaWduaW5nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEA4O9DV54tphJ0c/pAIiBWPleZHk3W8x23c8iSUKXEXkt9oXM73BUP
# vB/X4SiC9qJY5N+u76LrQc6x7uJGaOTe1Kq/V7t3H73mYOy26GX9Ol7xJTBweLOi
# ORLNHHdEUeiuVoGSQ504NqKOa3ZmyWr+TZcaPlIQ2QLxiUrk0Da3ndl5oH9LE0ZL
# IgTgvP4RqVMzpryAKCT+OqGgtyxAHs23+zM77FZ9Mrii8th8kPQ7dvalEl4k/sbV
# XN/K5x90iTviYy795DIoKHuC35O6c9I6Gl8nloActo207eofA0Cxeb1SoomXp9Zc
# ex6RZuKrTffCuxWHK+TgZt2r50l0kk31vQIDAQABo0YwRDAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFOxaXgyH1d9Xu8uB6zHF
# ImsWT0f9MA0GCSqGSIb3DQEBCwUAA4IBAQAuiFkjD9eyW5UWgGvp+dMId9Ayt0fa
# eNh3P1EWteWED/bNnDk3/DxXMmgx3BoPIxUyooA0O4rlbNsae2Ypk42ky29dB1DL
# 4jdHoK29DO90jL9L9bcYTtqxUlrBvK1XLQSPriNyjdsfnINWZq9dq9vWVCvEf02d
# 9BAnhB733oZq9tB4T58uIzKmNrBZ7NwclY6/oZfZgTO+y8DOU3jCUwIlNXTqma+y
# XAapQ2oeQecSHHSHE5LO5cmmwTmIIbEp7bBF/YzVPrruVacfQQLF3IIOwW6AajiA
# 3ZhPsRD4y92vnyRUVXMwQ9XtuGnZzjwCCES5tqDW1TlC+V3GLu6Ku4CvMYIB5DCC
# AeACAQEwMjAeMRwwGgYDVQQDDBNMZXZvIFNjcmlwdCBTaWduaW5nAhAw2lzR3mLm
# m0j2qvbW+ZG4MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAIoAKA
# AKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJdCarpEcfH0UlHsBiCAlCsD
# 1I+6NEhr0dkq2BAu9b8wMA0GCSqGSIb3DQEBAQUABIIBALltWKi39aHYUzRSDMvs
# DSF5J+qFirZQKfgTo0XxrslAjPOstH45kASrqsUuT9U4MpPW37eVlscWu04qbK4e
# 8+CQNH/E/HOQhY86SWh6CxJvcU1kboeCwgP1F9hqQvII4rZeDLYsIZLe6w5ZM2g2
# p7krTny8RnIQR9sVzNjKhv7dW9bs+ForrJ+/bpDrbiT8XXuGbnLEdutO9mlZF7TV
# Z3iqA65VTnhkAqbH4KSeK2M8FE3lpJPl6900hnOem2nAYqhIE0QLBlmfqU02cUKR
# 40PWIvPyaW4GUJoBYG7Yru0ia6biLVUTPSQkhE+8WpGPw09suGiD30qEIwyZiMnm
# S9k=
# SIG # End signature block
