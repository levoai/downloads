# Run this script as Administrator
$ErrorActionPreference = "Stop"

# Define paths based on script location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll64Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x64.dll"
$dll32Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x86.dll"
$logsDir = Join-Path -Path $scriptDir -ChildPath "logs"
$configPath = Join-Path -Path $scriptDir -ChildPath "levo_config.json"

# 1. Verify the DLLs exist
if (-not (Test-Path $dll64Path)) {
    Write-Error "64-bit DLL not found at $dll64Path. Please ensure it exists before continuing."
    exit
}
if (-not (Test-Path $dll32Path)) {
    Write-Error "32-bit DLL not found at $dll32Path. Please ensure it exists before continuing."
    exit
}

# 2. Create logs directory if it doesn't exist
if (-not (Test-Path -Path $logsDir -PathType Container)) {
    New-Item -ItemType Directory -Path $logsDir -Force
    Write-Output "Created logs directory at $logsDir"
}

# 3. Set permissions on the main directory and the logs directory
Write-Output "Setting permissions on $scriptDir and $logsDir..."
# Main directory permissions - with full control
$acl = Get-Acl -Path $scriptDir
$iisRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($iisRule)
Set-Acl -Path $scriptDir -AclObject $acl
Write-Output "Set full control permissions for IIS_IUSRS on main directory"

# Logs directory permissions - with full control
$logAcl = Get-Acl -Path $logsDir
$logRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$logAcl.AddAccessRule($logRule)
Set-Acl -Path $logsDir -AclObject $logAcl
Write-Output "Set full control permissions for IIS_IUSRS on logs directory"

# 4. Import WebAdministration module
Import-Module WebAdministration

# 5. Remove any existing module registrations
if (Get-WebGlobalModule -Name "LevoaiIISModule_x64" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x64"
    Write-Output "Removed existing 64-bit module registration"
}

if (Get-WebGlobalModule -Name "LevoaiIISModule_x86" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x86"
    Write-Output "Removed existing 32-bit module registration"
}

# 6. Register both modules with appropriate preconditions
Write-Output "Registering modules with appropriate preconditions..."

# Register 64-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x64";
    image = $dll64Path;
    preCondition = "bitness64"
}
Write-Output "Registered LevoaiIISModule_x64 as a global module with bitness64 precondition"

# Register 32-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x86";
    image = $dll32Path;
    preCondition = "bitness32"
}
Write-Output "Registered LevoaiIISModule_x86 as a global module with bitness32 precondition"

# 7. Add modules to the global modules collection
if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x64']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x64";
        preCondition = "bitness64"
    }
    Write-Output "Added LevoaiIISModule_x64 to global modules collection"
}

if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x86']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x86";
        preCondition = "bitness32"
    }
    Write-Output "Added LevoaiIISModule_x86 to global modules collection"
}

# 8. Restart IIS to apply changes
Write-Output "Restarting IIS to apply changes..."
iisreset
Write-Output "IIS has been restarted. Module deployment complete."

# 9. Display application pool configurations
Write-Output "`nApplication Pool Configurations:"
Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object {
    $poolName = $_.Name
    $is32Bit = ($_ | Get-ItemProperty).enable32BitAppOnWin64
    $moduleType = if ($is32Bit) { "LevoaiIISModule_x86 (32-bit)" } else { "LevoaiIISModule_x64 (64-bit)" }
    Write-Output "- $poolName`: $moduleType"
}

# 10. Output configuration information
Write-Output "`nDeployment completed with the following configuration:"
Write-Output "64-bit DLL Path: $dll64Path"
Write-Output "32-bit DLL Path: $dll32Path"
Write-Output "Logs Directory: $logsDir"
Write-Output "Config File: $configPath"
# SIG # Begin signature block
# MIIFngYJKoZIhvcNAQcCoIIFjzCCBYsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBap9jR+us1ynGp
# /9ncJenGYYnIblxJQjUxAO3RqsWmkqCCAxAwggMMMIIB9KADAgECAhBgXLWegB0e
# nkg996mN5Fm9MA0GCSqGSIb3DQEBCwUAMB4xHDAaBgNVBAMME0xldm8gU2NyaXB0
# IFNpZ25pbmcwHhcNMjUxMDAzMDc0NDMyWhcNMjYxMDAzMDgwNDMyWjAeMRwwGgYD
# VQQDDBNMZXZvIFNjcmlwdCBTaWduaW5nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
# MIIBCgKCAQEA7dgY4cB8e8NR+lpu7QrFCl9+ukdjREXAXZE2nsWxPyPxnlyBUXzj
# uMP3vpNcOoo1TTcWf5x+a4f9F9b560UzIKmUFu75TqQHPX9XaRq7yFN0ka+Yh7sN
# xdczHgJFJW58BTML7wMltJ+8mjt1s6Q/PYFbXKBOF+idUuqm4o8eTNCMmGGR9Eka
# lkSNsL3TQ2mrulpMA1jMJIqtcDwI3FwFsf95J11D3eR4XAmG4pK0bGXkJ1iTk8dP
# 0UslCCLnkwhqPANudNJimlQKHF/MO4ZvYHbiKwUHjHiN1jp1OP9zpbBWmwACzIVx
# x0iJpdo/23rWssMIlEYSE43jSOgsf2C6bQIDAQABo0YwRDAOBgNVHQ8BAf8EBAMC
# B4AwEwYDVR0lBAwwCgYIKwYBBQUHAwMwHQYDVR0OBBYEFNjkjo7ivqrkW5NBpjp7
# uxOYsPRzMA0GCSqGSIb3DQEBCwUAA4IBAQBqhrM02YllVMwnOYleRSC4taAVTBzE
# dZT5cKz3L/zRwL0014FkhjomugvKYtehOOoI/4qwmeOPPJXcf7imaZCGbklNFjQs
# 9Dd85Q2861CmeU/l5fxo9IkS84HsUxtck41xXn/wuuaunqkckfk8q7EGbzjLdo6N
# MpyUSREjHAAkEUo88xGIJmgiXFnfoZtT6bNgN6gQgpZvlCnhEZts+sd4ALgEwyNq
# d3/6mnzLLMRxmjZKCgav4mA4/rRYwUpGDb0/MAnO8Z9s6FG0lUjbobYVUvxMyfLc
# NKxkFSKjsr5eBqqXkA+lbsrJWFX6UNH9MhQJrurcOjl8xqbzAJ+3kMKRMYIB5DCC
# AeACAQEwMjAeMRwwGgYDVQQDDBNMZXZvIFNjcmlwdCBTaWduaW5nAhBgXLWegB0e
# nkg996mN5Fm9MA0GCWCGSAFlAwQCAQUAoIGEMBgGCisGAQQBgjcCAQwxCjAIoAKA
# AKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJdCarpEcfH0UlHsBiCAlCsD
# 1I+6NEhr0dkq2BAu9b8wMA0GCSqGSIb3DQEBAQUABIIBADoHl95bdAlWroki+ybu
# /JsisOi9bhtG9Od6blcEsufy8uyl4V7XTh3UaFdWXS68+4dID+dHhFyDcDYbxrPy
# tCYyAMMPHO3K2ktCrfuWKpDbc90Ew+4ieFb6+CY2+nSqnz/cJ5Ag/ZsCmKvko7va
# 2hkgMtCnumiAEcb54AYPS/GrET8QxRqwV94JZjI99dhOJVcRgQkSJE5KWNUDKoh8
# mBERgJ7mkPaljLgZKUxSv02e1Ymie0DmLGo/VTyYSfpaNRZx/FvY10lFjTGUrtS3
# lzoG1NbxH5u84ELlyRWEBMZYyy+stO4KK7Pt0a48/H61P0XfcmKS9zVmujsBxza7
# aDk=
# SIG # End signature block
