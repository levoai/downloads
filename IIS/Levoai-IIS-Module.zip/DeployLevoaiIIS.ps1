# Run this script as Administrator
$ErrorActionPreference = "Stop"

# Define paths based on script location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dllPath = Join-Path -Path $scriptDir -ChildPath "HttpLoggerModule.dll"
$logsDir = Join-Path -Path $scriptDir -ChildPath "logs"

# 1. Verify the DLL exists
if (-not (Test-Path $dllPath)) {
    Write-Error "DLL not found at $dllPath. Please ensure it exists before continuing."
    exit
}

# 2. Create and set permissions on logs directory
if (-not (Test-Path -Path $logsDir -PathType Container)) {
    New-Item -ItemType Directory -Path $logsDir -Force
    Write-Output "Created logs directory at $logsDir"
}

# Set proper permissions for IIS_IUSRS
$acl = Get-Acl -Path $logsDir
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "Read, Write", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($rule)
Set-Acl -Path $logsDir -AclObject $acl
Write-Output "Set permissions for IIS_IUSRS on logs directory"

# 3. Register the module with IIS
Import-Module WebAdministration

# Remove existing module registration if any
if (Get-WebGlobalModule -Name "HttpLoggerModule" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "HttpLoggerModule"
    Write-Output "Removed existing module registration"
}

# Add as global module
New-WebGlobalModule -Name "HttpLoggerModule" -Image $dllPath
Write-Output "Registered HttpLoggerModule as a global module"

# Add to modules collection (globally for all sites)
if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='HttpLoggerModule']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{name="HttpLoggerModule"}
    Write-Output "Added HttpLoggerModule to global modules collection"
}

# 4. Restart IIS to apply changes
Write-Output "Restarting IIS to apply changes..."
iisreset
Write-Output "IIS has been restarted. Module deployment complete."

# 5. Verify module is loaded
$modulesLoaded = Get-WebGlobalModule | Where-Object { $_.Name -eq "HttpLoggerModule" }
if ($modulesLoaded) {
    Write-Output "Verification: HttpLoggerModule is registered with IIS."
} else {
    Write-Warning "Verification failed: HttpLoggerModule is not registered with IIS."
}

# 6. Output configuration information
Write-Output "Deployment completed with the following configuration:"
Write-Output "DLL Path: $dllPath"
Write-Output "Logs Directory: $logsDir"