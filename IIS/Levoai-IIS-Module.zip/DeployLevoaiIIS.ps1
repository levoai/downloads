# Run this script as Administrator
$ErrorActionPreference = "Stop"

# Define paths based on script location
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$dll64Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x64.dll"
$dll32Path = Join-Path -Path $scriptDir -ChildPath "LevoaiIISModule_x86.dll"
$logsDir = Join-Path -Path $scriptDir -ChildPath "logs"
$configPath = Join-Path -Path $scriptDir -ChildPath "levo_config.json"

# 1. Verify the DLLs exist
if (-not (Test-Path $dll64Path)) {
    Write-Error "64-bit DLL not found at $dll64Path. Please ensure it exists before continuing."
    exit
}
if (-not (Test-Path $dll32Path)) {
    Write-Error "32-bit DLL not found at $dll32Path. Please ensure it exists before continuing."
    exit
}

# 2. Create logs directory if it doesn't exist
if (-not (Test-Path -Path $logsDir -PathType Container)) {
    New-Item -ItemType Directory -Path $logsDir -Force
    Write-Output "Created logs directory at $logsDir"
}

# 3. Set permissions on the main directory and the logs directory
Write-Output "Setting permissions on $scriptDir and $logsDir..."
# Main directory permissions - with full control
$acl = Get-Acl -Path $scriptDir
$iisRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.AddAccessRule($iisRule)
Set-Acl -Path $scriptDir -AclObject $acl
Write-Output "Set full control permissions for IIS_IUSRS on main directory"

# Logs directory permissions - with full control
$logAcl = Get-Acl -Path $logsDir
$logRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS_IUSRS", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
$logAcl.AddAccessRule($logRule)
Set-Acl -Path $logsDir -AclObject $logAcl
Write-Output "Set full control permissions for IIS_IUSRS on logs directory"

# 4. Import WebAdministration module
Import-Module WebAdministration

# 5. Remove any existing module registrations
if (Get-WebGlobalModule -Name "LevoaiIISModule_x64" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x64"
    Write-Output "Removed existing 64-bit module registration"
}

if (Get-WebGlobalModule -Name "LevoaiIISModule_x86" -ErrorAction SilentlyContinue) {
    Remove-WebGlobalModule -Name "LevoaiIISModule_x86"
    Write-Output "Removed existing 32-bit module registration"
}

# 6. Register both modules with appropriate preconditions
Write-Output "Registering modules with appropriate preconditions..."

# Register 64-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x64";
    image = $dll64Path;
    preCondition = "bitness64"
}
Write-Output "Registered LevoaiIISModule_x64 as a global module with bitness64 precondition"

# Register 32-bit module
Add-WebConfiguration -Filter "/system.webServer/globalModules" -Value @{
    name = "LevoaiIISModule_x86";
    image = $dll32Path;
    preCondition = "bitness32"
}
Write-Output "Registered LevoaiIISModule_x86 as a global module with bitness32 precondition"

# 7. Add modules to the global modules collection
if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x64']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x64";
        preCondition = "bitness64"
    }
    Write-Output "Added LevoaiIISModule_x64 to global modules collection"
}

if (-not (Get-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules/add[@name='LevoaiIISModule_x86']" -ErrorAction SilentlyContinue)) {
    Add-WebConfiguration -PSPath "MACHINE/WEBROOT/APPHOST" -Filter "system.webServer/modules" -Value @{
        name = "LevoaiIISModule_x86";
        preCondition = "bitness32"
    }
    Write-Output "Added LevoaiIISModule_x86 to global modules collection"
}

# 8. Restart IIS to apply changes
Write-Output "Restarting IIS to apply changes..."
iisreset
Write-Output "IIS has been restarted. Module deployment complete."

# 9. Display application pool configurations
Write-Output "`nApplication Pool Configurations:"
Get-ChildItem -Path IIS:\AppPools\ | ForEach-Object {
    $poolName = $_.Name
    $is32Bit = ($_ | Get-ItemProperty).enable32BitAppOnWin64
    $moduleType = if ($is32Bit) { "LevoaiIISModule_x86 (32-bit)" } else { "LevoaiIISModule_x64 (64-bit)" }
    Write-Output "- $poolName`: $moduleType"
}

# 10. Output configuration information
Write-Output "`nDeployment completed with the following configuration:"
Write-Output "64-bit DLL Path: $dll64Path"
Write-Output "32-bit DLL Path: $dll32Path"
Write-Output "Logs Directory: $logsDir"
Write-Output "Config File: $configPath"