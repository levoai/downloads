package ai.levo.bootstrap.sunsecurity.appoutputstreamadvice;

import ai.levo.bootstrap.erpc.Erpc;
import net.bytebuddy.asm.Advice;

public class AppOutputStreamAdviceWriteInt {
  @Advice.OnMethodEnter
  public static void onEnter(@Advice.Argument(0) int b) {
    // System.out.println("[levo] AppOutputStream.write(int) -> " + b);
    Erpc erpc = new Erpc();
    erpc.sendIoctlMessage(String.valueOf((char) b), 3);
  }
}
