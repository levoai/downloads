package ai.levo.bootstrap.sunsecurity;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.model.SocketConnection;
import ai.levo.bootstrap.utils.SocketInspector;
import net.bytebuddy.asm.Advice;

public class SSLSocketImplAcceptAdvice {
  @Advice.OnMethodEnter
  public static void onAccept(@Advice.This Object socket) {

    // System.out.println("[levo] Socket is being opened: " + socket);
    SocketInspector socketInspector = new SocketInspector();
    SocketConnection connection = socketInspector.extractSocket5Tuple(socket);
    // System.out.println("[levo] Extracted connection: " + connection.toString());
    Erpc erpc = new Erpc();
    erpc.sendIoctlSocketLifecycleInfo(connection, 0);
  }
}
