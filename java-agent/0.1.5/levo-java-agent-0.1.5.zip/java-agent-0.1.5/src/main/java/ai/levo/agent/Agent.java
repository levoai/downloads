package ai.levo.agent;

import ai.levo.instrument.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.jar.JarFile;
import net.bytebuddy.dynamic.ClassFileLocator;
import org.slf4j.Logger;

public class Agent {
  private static final Logger logger = org.slf4j.LoggerFactory.getLogger(Agent.class);

  public static void premain(String agentArgs, Instrumentation inst) {
    logger.info("Retransform supported: " + inst.isRetransformClassesSupported());
    attachAgent(agentArgs, inst);
  }

  public static void agentmain(String agentArgs, Instrumentation inst) {
    attachAgent(agentArgs, inst);
  }

  private static void attachAgent(String agentArgs, Instrumentation inst) {
    try {
      Map<String, Boolean> config = parseAgentArgs(agentArgs);

      File bootstrapJar;
      File agentJar =
          new File(Agent.class.getProtectionDomain().getCodeSource().getLocation().toURI());

      File agentDir = agentJar.getParentFile();
      File[] bootstrapCandidates =
          agentDir.listFiles(
              (dir, name) -> name.startsWith("levo-agent-bootstrap") && name.endsWith(".jar"));

      if (bootstrapCandidates != null && bootstrapCandidates.length > 0) {
        bootstrapJar = bootstrapCandidates[0]; // Pick the first match
        // Use bootstrapJar as needed
      } else {
        throw new FileNotFoundException(
            "No bootstrap JAR found starting with 'levo-agent-bootstrap'");
      }
      inst.appendToBootstrapClassLoaderSearch(new JarFile(bootstrapJar));

      ClassFileLocator bootstrapLocator = ClassFileLocator.ForJarFile.of(bootstrapJar);

      if (config.getOrDefault("TraceClientTrafficOnly", false)) {
        logger.info("TraceClientTrafficOnly is enabled");
        System.setProperty("levo.trace.client.traffic.only", "true");
      }
      // Conditionally instrument based on configuration
      // Enable only SunSecuritySslInstrumentation by default
      if (config.getOrDefault("SunSecuritySslInstrumentation", true)) {
        SunSecuritySslInstrumentation.instrument(inst, bootstrapLocator);
        logger.info("SunSecuritySslInstrumentation enabled");
      }

      if (config.getOrDefault("JavaxSslSocketStreamInstrumentation", false)) {
        JavaxSslSocketInstrumentation.instrument(inst, bootstrapLocator);
        logger.info("JavaxSslSocketStreamInstrumentation enabled");
      }

      if (config.getOrDefault("JRubyOpensslInstrumentation", false)) {
        JRubyOpensslInstrumentation.instrument(inst, bootstrapLocator);
        logger.info("JRubyOpensslInstrumentation enabled");
      }

      if (config.getOrDefault("JavaxSSLEngineInstrumentation", false)) {
        JavaxSSLEngineInstrumentation.instrument(inst, bootstrapLocator);
        logger.info("JavaxSSLEngineInstrumentation enabled");
      }

    } catch (URISyntaxException | IOException | UnmodifiableClassException e) {
      throw new RuntimeException(e);
    }
  }

  private static Map<String, Boolean> parseAgentArgs(String agentArgs) {
    Map<String, Boolean> config = new HashMap<>();
    if (agentArgs != null && !agentArgs.isEmpty()) {
      String[] args = agentArgs.split(",");
      for (String arg : args) {
        String[] keyValue = arg.split("=");
        if (keyValue.length == 2) {
          config.put(keyValue[0].trim(), Boolean.parseBoolean(keyValue[1].trim()));
        }
      }
    }
    return config;
  }
}
