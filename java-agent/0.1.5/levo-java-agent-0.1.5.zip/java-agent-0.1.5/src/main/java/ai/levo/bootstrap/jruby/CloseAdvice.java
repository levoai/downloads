package ai.levo.bootstrap.jruby;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.model.SocketConnection;
import ai.levo.bootstrap.utils.SocketInspector;
import net.bytebuddy.asm.Advice;

public class CloseAdvice {

  @Advice.OnMethodEnter
  public static void onEnter(@Advice.This Object socket) {
    SocketInspector socketInspector = new SocketInspector();
    SocketConnection connection = socketInspector.extractSocket5Tuple(socket);
    Erpc erpc = new Erpc();
    // System.out.println("JRuby close advice");
    erpc.sendIoctlSocketLifecycleInfo(connection, 1);
  }
}
