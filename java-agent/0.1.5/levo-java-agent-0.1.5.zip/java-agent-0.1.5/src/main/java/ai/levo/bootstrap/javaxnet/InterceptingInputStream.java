package ai.levo.bootstrap.javaxnet;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class InterceptingInputStream extends FilterInputStream {

  public InterceptingInputStream(InputStream in) {
    super(in);
    System.out.println("Created new InterceptingInputStream for socket: ");
  }

  @Override
  public void close() {
    System.out.println("InputStream Close");
  }

  @Override
  public int read() throws IOException {
    int value = super.read();
    System.out.println("Read single byte: " + value);
    return value;
  }

  @Override
  public int read(byte[] b) throws IOException {
    int count = super.read(b);
    if (count > 0) {
      System.out.println("Read " + count + " bytes: " + new String(b, 0, count));
    }
    return count;
  }

  @Override
  public int read(byte[] b, int off, int len) throws IOException {
    int count = super.read(b, off, len);
    if (count > 0) {
      System.out.println(
          "Read " + count + " bytes with offset " + off + ": " + new String(b, off, count));
    }
    return count;
  }
}
