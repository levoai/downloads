package ai.levo.bootstrap.erpc;

import ai.levo.bootstrap.model.SocketConnection;
import java.nio.charset.StandardCharsets;

/**
 * This class is used to send data to the eBPF sensor. It used an ioctl syscall with a dedicated
 * request code that can be handled by the eBPF code.
 */
public class Erpc {

  // Same ioctl code used in BPF script
  private NativeIoctl nativeIoctl;
  private final int IOCTL_DIR = 3; // _IOC_DIR_READ_WRITE
  private final int SOCKET_IOCTL_TYPE = 0xda; // Unique identifier for Socket info
  private final int DATA_IOCTL_TYPE = 0xdb; // Unique identifier for Data info
  private final int SOCKET_IOCTL_TYPE_NIO = 0xdc;
  private final int DATA_IOCTL_TYPE_NIO = 0xdd;
  private final int IOCTL_NR = 0x7a;
  private final int IOCTL_SIZE = ((2 << 14) - 1);

  // Keep this half of IOCTL_SIZE to leave room for metadata and avoid overflow
  private final int CHUNK_SIZE_BYTES = IOCTL_SIZE / 2;
  private final long SOCKET_IOCTL_CODE = _IOW(IOCTL_DIR, SOCKET_IOCTL_TYPE, IOCTL_NR, IOCTL_SIZE);
  private final long DATA_IOCTL_CODE = _IOW(IOCTL_DIR, DATA_IOCTL_TYPE, IOCTL_NR, IOCTL_SIZE);
  private final short EVENT_TYPE_VERSION = 1;

  // TODO: Implement for NIO versions
  private final long SOCKET_IOCTL_NIO_CODE =
      _IOW(IOCTL_DIR, SOCKET_IOCTL_TYPE_NIO, IOCTL_NR, IOCTL_SIZE);
  private final long DATA_IOCTL_NIO_CODE =
      _IOW(IOCTL_DIR, DATA_IOCTL_TYPE_NIO, IOCTL_NR, IOCTL_SIZE);

  private long _IOW(int dir, int type, int nr, int size) {
    return _IOC(dir, type, nr, size);
  }

  private long _IOC(int dir, int type, int nr, int size) {
    return ((long) dir << 30) | ((long) type << 8) | ((long) nr << 0) | ((long) size << 16);
  }

  public Erpc() {
    nativeIoctl = new NativeIoctl(IOCTL_SIZE);
    nativeIoctl.address = nativeIoctl.allocateNativeMemory(IOCTL_SIZE);
  }

  //    public void main(String[] args) {
  //        // sendIoctlMessage("HelloFromJava");
  //    }

  public void sendIoctlMessage(String message, int event) {
    byte[] msgBytes = message.getBytes(StandardCharsets.UTF_8);
    int chunkSize = CHUNK_SIZE_BYTES;
    int totalChunks = (msgBytes.length + chunkSize - 1) / chunkSize;

    for (int chunk = 0; chunk < totalChunks; chunk++) {
      try {
        // Zero out the entire buffer first
        nativeIoctl.clearMemory(nativeIoctl.address, nativeIoctl.size);
        long offset = 0;
        int pid = nativeIoctl.getPid();
        long threadId = Thread.currentThread().getId();

        nativeIoctl.writeShortToMemory(nativeIoctl.address, offset, EVENT_TYPE_VERSION);
        offset += 2;

        nativeIoctl.writeByteToMemory(nativeIoctl.address, offset, (byte) event);
        offset += 1;

        // Write process and thread IDs
        nativeIoctl.writeIntToMemory(nativeIoctl.address, offset, pid);
        offset += 4;
        nativeIoctl.writeLongToMemory(nativeIoctl.address, offset, threadId);
        offset += 8;

        // Calculate chunk boundaries
        int startIdx = chunk * chunkSize;
        int endIdx = Math.min(startIdx + chunkSize, msgBytes.length);
        int currentChunkSize = endIdx - startIdx;

        // Write chunk length
        nativeIoctl.writeIntToMemory(nativeIoctl.address, offset, currentChunkSize);
        offset += 4;

        // Write chunk data
        nativeIoctl.writeBytesToMemory(
            nativeIoctl.address, offset, msgBytes, startIdx, currentChunkSize);

        // Call ioctl
        long nativeFd = 0; // Your file descriptor
        long argp = nativeIoctl.address;
        long ret =
            nativeIoctl.nativeIoctl(
                nativeFd, DATA_IOCTL_CODE, argp); // for some returning -1 even on success

        //                if (ret != 0) {
        //                    System.err.println("DATA_IOCTL failed with return code: " + ret);
        //                }
      } catch (Exception e) {
        throw new RuntimeException(e);
      }
    }
  }

  public void sendIoctlSocketLifecycleInfo(SocketConnection connection, int event) {
    try {
      if (connection == null) {
        connection = new SocketConnection();
      }

      nativeIoctl.clearMemory(nativeIoctl.address, nativeIoctl.size);
      long offset = 0;

      nativeIoctl.writeShortToMemory(nativeIoctl.address, offset, EVENT_TYPE_VERSION);
      offset += 2;

      // Write IPs
      byte[] localIp = connection.getLocalAddress().getBytes(StandardCharsets.UTF_8);
      byte[] remoteIp = connection.getRemoteAddress().getBytes(StandardCharsets.UTF_8);
      nativeIoctl.writeBytesToMemory(
          nativeIoctl.address, offset, localIp, 0, Math.min(localIp.length, 16));
      offset += 16;
      nativeIoctl.writeBytesToMemory(
          nativeIoctl.address, offset, remoteIp, 0, Math.min(remoteIp.length, 16));
      offset += 16;

      // Write ports
      nativeIoctl.writeShortToMemory(
          nativeIoctl.address, offset, (short) connection.getLocalPort());
      offset += 2;
      nativeIoctl.writeShortToMemory(
          nativeIoctl.address, offset, (short) connection.getRemotePort());
      offset += 2;

      // Write event type
      nativeIoctl.writeByteToMemory(nativeIoctl.address, offset, (byte) event);
      offset += 1;

      // Write process and thread ID
      int pid = connection.getPid() == 0 ? nativeIoctl.getPid() : connection.getPid();
      nativeIoctl.writeIntToMemory(nativeIoctl.address, offset, pid);
      offset += 4;
      nativeIoctl.writeLongToMemory(nativeIoctl.address, offset, connection.getThreadId());
      offset += 8;
      nativeIoctl.writeByteToMemory(nativeIoctl.address, offset, connection.getAddrFamily());

      // Call ioctl
      long nativeFd = 0;
      long argp = nativeIoctl.address;
      long ret = nativeIoctl.nativeIoctl(nativeFd, SOCKET_IOCTL_CODE, argp);

      //            if (ret != 0) {
      //                System.err.println("SOCKET_IOCTL failed with return code: " + ret);
      //            }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
