package ai.levo.bootstrap.utils;

import ai.levo.bootstrap.model.SocketConnection;
import java.lang.reflect.Field;
import java.net.*;
import java.nio.channels.SocketChannel;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SocketInspector {

  //    private static final Logger logger =
  // org.slf4j.LoggerFactory.getLogger(SocketInspector.class);

  private boolean shouldRecurse(Class<?> type, String fieldName, Object value) {
    Set<Class<?>> SKIP_RECURSE_TYPES =
        new HashSet<>(
            Arrays.asList(
                String.class,
                Integer.class,
                Long.class,
                Boolean.class,
                Byte.class,
                Short.class,
                Double.class,
                Float.class,
                Character.class,
                InetAddress.class,
                InetSocketAddress.class,
                Class.class));

    if (value == null) return false;
    if (type.isPrimitive()) return false;
    if (SKIP_RECURSE_TYPES.contains(type)) return false;

    String className = type.getName();
    if (className.startsWith("java.")
        || className.startsWith("javax.")
        || className.startsWith("sun.")) {
      return (value instanceof Socket || value instanceof SocketChannel);
    }

    return fieldName.toLowerCase().contains("socket")
        || fieldName.toLowerCase().contains("channel");
  }

  private Socket unwrapSocket(Object obj) {
    if (obj instanceof Socket) return (Socket) obj;

    Class<?> clazz = obj.getClass();
    while (clazz != null) {
      // logger.debug("Inspecting class: " + clazz.getName());
      for (Field field : clazz.getDeclaredFields()) {
        field.setAccessible(true);
        try {
          Object val = field.get(obj);
          if (shouldRecurse(field.getType(), field.getName(), val)) {
            Socket s = unwrapSocket(val);
            if (s != null) return s;
          }
        } catch (IllegalAccessException ignored) {
        }
      }
      clazz = clazz.getSuperclass();
    }
    return null;
  }

  public SocketConnection extractSocket5Tuple(Object obj) {
    try {
      SocketConnection socketConnection = null;
      Socket socket = unwrapSocket(obj);
      if (socket != null) {
        InetAddress localAddr = socket.getLocalAddress();
        InetAddress remoteAddr = socket.getInetAddress();
        int localPort = socket.getLocalPort();
        int remotePort = socket.getPort();
        // Get process info using JNA
        // long pid =
        // Integer.parseInt(ManagementFactory.getRuntimeMXBean().getName().split("@")[0]);
        long threadId = Thread.currentThread().getId();
        byte addrFamily = 0;
        if (localAddr instanceof Inet6Address) {
          addrFamily = 6;
        } else if (localAddr instanceof Inet4Address) {
          addrFamily = 4;
        }
        socketConnection =
            new SocketConnection(
                localAddr, localPort, remoteAddr, remotePort, threadId, 0, addrFamily);
        //                logger.debug("threadID: {}, pid: {}, 5-Tuple: {}:{} → {}:{}",
        //                        threadId, pid,
        //                        localAddr.getHostAddress(), localPort,
        //                        remoteAddr.getHostAddress(), remotePort);
      } else {
        //                logger.debug("Could not unwrap socket.");
      }
      return socketConnection;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }
}
