package ai.levo.bootstrap.erpc;

public class NativeIoctl {

  private final String LIBRARY_NAME = "libnative_ioctl.so";
  private final String DEFAULT_LIBRARY_PATH = "/usr/lib/" + LIBRARY_NAME;
  private final String NATIVE_IOCTL_LIB_LOADED_SYS_PROPERTY_KEY = "native.ioctl.lib.loaded";

  private synchronized void loadNativeLibrary() {

    // cannot use static block here, hence using system property
    // to avoid loading the library multiple times.
    if (Boolean.getBoolean(NATIVE_IOCTL_LIB_LOADED_SYS_PROPERTY_KEY)) {
      // System.out.println("Library already loaded");
      return;
    }
    try {
      String libNativeIoctlFilePath = System.getenv("LIB_NATIVE_IOCTL_FILE_PATH");
      if (libNativeIoctlFilePath == null || libNativeIoctlFilePath.isEmpty()) {
        // Default path if the environment variable is not set
        libNativeIoctlFilePath = DEFAULT_LIBRARY_PATH;
      }
      // System.out.println(libNativeIoctlFilePath);
      System.load(libNativeIoctlFilePath);
      System.setProperty(NATIVE_IOCTL_LIB_LOADED_SYS_PROPERTY_KEY, "true");
    } catch (UnsatisfiedLinkError e) {
      System.err.println("Failed to load libnative_ioctl.so: " + e.getMessage());
    }
  }

  public long address = 0;
  public final long size;

  public NativeIoctl(long size) {
    loadNativeLibrary();
    this.size = size;
  }

  // Native method declarations
  public native long nativeIoctl(long fd, long request, long arg);

  public native long allocateNativeMemory(long size);

  public native void freeNativeMemory(long address);

  public native void writeByteToMemory(long address, long offset, byte value);

  public native void writeLongToMemory(long address, long offset, long value);

  public native void writeIntToMemory(long address, long offset, int value);

  public native void writeShortToMemory(long address, long offset, short value);

  public native void writeBytesToMemory(
      long address, long offset, byte[] data, int start, int length);

  public native void clearMemory(long address, long size);

  public native int getPid();
}
