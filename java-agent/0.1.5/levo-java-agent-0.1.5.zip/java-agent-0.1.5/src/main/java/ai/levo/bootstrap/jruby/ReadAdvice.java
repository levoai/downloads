package ai.levo.bootstrap.jruby;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.utils.HTTPRegexMatcher;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import net.bytebuddy.asm.Advice;

public class ReadAdvice {

  @Advice.OnMethodExit
  public static void onExit(
      @Advice.Origin String method,
      @Advice.This Object socket,
      @Advice.Argument(0) ByteBuffer buffer,
      @Advice.Return int bytesRead) {

    // System.out.println("ReadAdvice called for method: " + method);
    if (bytesRead <= 0) return; // Skip if no data was read

    // Save original position
    int originalPosition = buffer.position();

    try {
      // Move position back by bytesRead to get the fresh data
      buffer.position(originalPosition - bytesRead);

      // Read only the bytes that were just read
      byte[] data = new byte[bytesRead];
      buffer.get(data);

      String message = new String(data, StandardCharsets.UTF_8);

      boolean traceClientTrafficOnly =
          System.getProperty("levo.trace.client.traffic.only") != null
              && System.getProperty("levo.trace.client.traffic.only").equalsIgnoreCase("true");

      String payloadType = null;
      if (traceClientTrafficOnly) {
        HTTPRegexMatcher httpRegexMatcher = new HTTPRegexMatcher();
        payloadType = httpRegexMatcher.detectPayloadType(message);
      }
      if (!traceClientTrafficOnly
          || (payloadType != null && payloadType.equalsIgnoreCase("RESPONSE"))) {
        Erpc erpc = new Erpc();
        erpc.sendIoctlMessage(message, 2);
      }
    } finally {
      // Restore buffer position
      buffer.position(originalPosition);
    }
  }
}
