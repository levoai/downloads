package ai.levo.instrument;

import ai.levo.bootstrap.javaxnet.InterceptingInputStream;
import ai.levo.bootstrap.javaxnet.InterceptingOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import net.bytebuddy.asm.Advice;

public class StreamAdvice {
  public static class GetInputStreamAdvice {
    @Advice.OnMethodExit
    public static void intercept(@Advice.Return(readOnly = false) InputStream returnValue) {
      if (returnValue != null) {
        returnValue = new InterceptingInputStream(returnValue);
      }
    }
  }

  public static class GetOutputStreamAdvice {
    @Advice.OnMethodExit
    public static void intercept(@Advice.Return(readOnly = false) OutputStream returnValue) {
      if (returnValue != null) {
        returnValue = new InterceptingOutputStream(returnValue);
      }
    }
  }
}
