package ai.levo.bootstrap.sunsecurity.appoutputstreamadvice;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.utils.HTTPRegexMatcher;
import net.bytebuddy.asm.Advice;

public class AppOutputStreamAdviceWriteByteArray {

  @Advice.OnMethodEnter
  public static void onEnter(@Advice.Argument(0) byte[] data) {
    // System.out.println("[levo] AppOutputStream.write(byte[]) -> " + new String(b));
    String message = new String(data);
    boolean traceClientTrafficOnly =
        System.getProperty("levo.trace.client.traffic.only") != null
            && System.getProperty("levo.trace.client.traffic.only").equalsIgnoreCase("true");

    String payloadType = null;
    if (traceClientTrafficOnly) {
      HTTPRegexMatcher httpRegexMatcher = new HTTPRegexMatcher();
      payloadType = httpRegexMatcher.detectPayloadType(message);
    }
    if (!traceClientTrafficOnly
        || (payloadType != null && payloadType.equalsIgnoreCase("REQUEST"))) {
      Erpc erpc = new Erpc();
      erpc.sendIoctlMessage(message, 3);
    }
  }
}
