package ai.levo.instrument;

import static net.bytebuddy.matcher.ElementMatchers.*;

import ai.levo.bootstrap.javaxnet.*;
import java.lang.instrument.Instrumentation;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.dynamic.ClassFileLocator;
import org.slf4j.Logger;

public class JavaxSslSocketInstrumentation {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(JavaxSslSocketInstrumentation.class);

  public static void instrument(Instrumentation inst, ClassFileLocator bootstrapLocator) {
    logger.info("Instrumenting JavaxSslSocketStreamInstrumentation");
    new AgentBuilder.Default()
        .with(AgentBuilder.Listener.StreamWriting.toSystemOut().withTransformationsOnly())
        .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
        .ignore(none()) // Don’t ignore anything
        .type(nameStartsWith("javax.net.ssl.SSLSocket"))
        .transform(
            (builder, typeDescription, classLoader, module, protectionDomain) ->
                builder
                    .method(named("getInputStream"))
                    .intercept(Advice.to(StreamAdvice.GetInputStreamAdvice.class))
                    .method(named("getOutputStream"))
                    .intercept(Advice.to(StreamAdvice.GetOutputStreamAdvice.class)))
        .installOn(inst);
  }
}
