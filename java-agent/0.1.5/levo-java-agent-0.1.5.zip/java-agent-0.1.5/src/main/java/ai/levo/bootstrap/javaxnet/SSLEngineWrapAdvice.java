package ai.levo.bootstrap.javaxnet;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.utils.HTTPRegexMatcher;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import javax.net.ssl.SSLEngineResult;
import net.bytebuddy.asm.Advice;

public class SSLEngineWrapAdvice {

  @Advice.OnMethodExit
  static void onExit(
      @Advice.Return Object result,
      @Advice.Origin Method method,
      @Advice.AllArguments Object[] args) {

    String message = null;
    String payloadType = null;
    boolean traceClientTrafficOnly =
        System.getProperty("levo.trace.client.traffic.only") != null
            && System.getProperty("levo.trace.client.traffic.only").equalsIgnoreCase("true");

    if (args.length >= 2 && args[0] instanceof ByteBuffer) {
      ByteBuffer src = (ByteBuffer) args[0];
      byte[] buf = new byte[src.position()];
      ByteBuffer copy = src.duplicate();
      copy.flip();
      copy.get(buf);
      message = new String(buf, StandardCharsets.UTF_8);
      if (traceClientTrafficOnly) {
        HTTPRegexMatcher httpRegexMatcher = new HTTPRegexMatcher();
        payloadType = httpRegexMatcher.detectPayloadType(message);
      }
      //      System.out.printf(
      //          "[levo] PID: %d\nThreadID: %d\n Outgoing Plaintext: %s\n",
      //          ProcessHandle.current().pid(), Thread.currentThread().getId(), message);
    }

    if ((!traceClientTrafficOnly
            || (payloadType != null && payloadType.equalsIgnoreCase("REQUEST")))
        && result instanceof SSLEngineResult) {
      // System.out.println("[levo] Wrap, payloadType: " + payloadType);
      SSLEngineResult.Status status = ((SSLEngineResult) result).getStatus();
      // System.out.println("[levo] result status = " + status.name());
      if (status == SSLEngineResult.Status.OK || status == SSLEngineResult.Status.CLOSED) {
        try {
          Erpc erpc = new Erpc();
          erpc.sendIoctlSocketLifecycleInfo(null, 0);

          if (message != null && !message.isEmpty()) {
            erpc.sendIoctlMessage(message, 3);
          }
        } catch (Exception e) {
          System.err.println(e.getMessage());
        }
      }
    }
  }
}
