package ai.levo.bootstrap.utils;

import java.util.regex.Pattern;

public class HTTPRegexMatcher {
  // Regular expression to match HTTP request line
  public final String HTTP_REQUEST_REGEX =
      "^(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH)\\s+([^\\s]+)\\s+HTTP/1\\.[01]$";

  // Regular expression to match HTTP response status line
  public final String HTTP_RESPONSE_REGEX =
      "^HTTP/1\\.[01]\\s+(200|201|202|204|301|400|401|403|404|500)\\s+.*$";

  private final Pattern REQUEST_PATTERN = Pattern.compile(HTTP_REQUEST_REGEX, Pattern.MULTILINE);
  private final Pattern STATUS_PATTERN = Pattern.compile(HTTP_RESPONSE_REGEX, Pattern.MULTILINE);
  /**
   * Detects if the payload is an HTTP request or response based on the first line.
   *
   * @param payload The HTTP payload as a string.
   * @return "REQUEST" if it matches a request line, "RESPONSE" if it matches a response line,
   *     otherwise an empty string.
   */
  public String detectPayloadType(String payload) {
    if (payload == null || payload.trim().isEmpty()) {
      return "";
    }

    // Get the first line of the payload
    String firstLine = getFirstLine(payload);

    // Check if it matches request pattern
    if (REQUEST_PATTERN.matcher(firstLine).matches()) {
      return "REQUEST";
    }

    // Check if it matches response pattern
    if (STATUS_PATTERN.matcher(firstLine).matches()) {
      return "RESPONSE";
    }

    return "";
  }

  /** Checks if payload contains a request line */
  public boolean containsRequestLine(String payload) {
    return payload != null && REQUEST_PATTERN.matcher(payload).find();
  }

  /** Checks if payload contains a status line */
  public boolean containsStatusLine(String payload) {
    return payload != null && STATUS_PATTERN.matcher(payload).find();
  }

  /** Extract the first line from the payload */
  private static String getFirstLine(String payload) {
    int newlineIndex = payload.indexOf('\n');
    if (newlineIndex == -1) {
      return payload.trim();
    }
    String firstLine = payload.substring(0, newlineIndex).trim();
    // Remove carriage return if present
    if (firstLine.endsWith("\r")) {
      firstLine = firstLine.substring(0, firstLine.length() - 1);
    }
    return firstLine;
  }
}
