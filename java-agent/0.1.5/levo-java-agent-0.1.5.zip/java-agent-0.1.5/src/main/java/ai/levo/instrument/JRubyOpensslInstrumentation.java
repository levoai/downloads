package ai.levo.instrument;

import static net.bytebuddy.matcher.ElementMatchers.*;

import ai.levo.bootstrap.jruby.AcceptAdvice;
import ai.levo.bootstrap.jruby.CloseAdvice;
import ai.levo.bootstrap.jruby.ReadAdvice;
import ai.levo.bootstrap.jruby.WriteAdvice;
import java.lang.instrument.Instrumentation;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.dynamic.ClassFileLocator;
import org.slf4j.Logger;

public class JRubyOpensslInstrumentation {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(JRubyOpensslInstrumentation.class);

  public static void instrument(Instrumentation inst, ClassFileLocator bootstrapLocator) {

    logger.info("Instrumenting JRubyOpensslInstrumentation");
    new AgentBuilder.Default()
        .ignore(none())
        .disableClassFormatChanges()
        .with(AgentBuilder.Listener.StreamWriting.toSystemOut().withTransformationsOnly())
        .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
        .with(AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.Reiterating.INSTANCE)
        .with(AgentBuilder.InitializationStrategy.NoOp.INSTANCE)
        .with(AgentBuilder.TypeStrategy.Default.REDEFINE)
        .type(nameMatches("org.jruby.ext.openssl.SSLSocket"))
        .transform(
            (builder, typeDescription, classLoader, module, protectionDomain) ->
                builder
                    .visit(Advice.to(AcceptAdvice.class, bootstrapLocator).on(named("acceptImpl")))
                    .visit(Advice.to(CloseAdvice.class, bootstrapLocator).on(named("close")))
                    .visit(Advice.to(ReadAdvice.class, bootstrapLocator).on(named("read")))
                    .visit(Advice.to(WriteAdvice.class, bootstrapLocator).on(named("write"))))
        .installOn(inst);
  }
}
