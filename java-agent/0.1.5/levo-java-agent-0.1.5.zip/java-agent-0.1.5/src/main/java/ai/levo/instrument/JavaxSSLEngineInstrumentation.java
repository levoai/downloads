package ai.levo.instrument;

import static net.bytebuddy.matcher.ElementMatchers.*;

import ai.levo.bootstrap.javaxnet.SSLEngineUnwrapAdvice;
import ai.levo.bootstrap.javaxnet.SSLEngineWrapAdvice;
import java.lang.instrument.Instrumentation;
import java.nio.ByteBuffer;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.dynamic.ClassFileLocator;
import org.slf4j.Logger;

public class JavaxSSLEngineInstrumentation {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(JavaxSslSocketInstrumentation.class);

  public static void instrument(Instrumentation inst, ClassFileLocator bootstrapLocator) {
    logger.info("Instrumenting JavaxSslEngineInstrumentation");
    new AgentBuilder.Default()
        .with(AgentBuilder.Listener.StreamWriting.toSystemOut().withTransformationsOnly())
        .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
        .ignore(none()) // Don’t ignore anything
        .type(nameStartsWith("javax.net.ssl.SSLEngine"))
        .transform(
            (builder, typeDescription, classLoader, module, protectionDomain) ->
                builder
                    .visit(
                        Advice.to(SSLEngineUnwrapAdvice.class, bootstrapLocator)
                            .on(
                                named("unwrap")
                                    .and(takesArgument(0, ByteBuffer.class))
                                    .and(takesArgument(1, ByteBuffer.class))
                                    .and(returns(named("javax.net.ssl.SSLEngineResult")))))
                    .visit(
                        Advice.to(SSLEngineWrapAdvice.class, bootstrapLocator)
                            .on(
                                named("wrap")
                                    .and(takesArgument(0, ByteBuffer.class))
                                    .and(takesArgument(1, ByteBuffer.class)))))
        .installOn(inst);
  }
}
