package ai.levo.bootstrap.jruby;

import ai.levo.bootstrap.erpc.Erpc;
import ai.levo.bootstrap.model.SocketConnection;
import ai.levo.bootstrap.utils.SocketInspector;
import net.bytebuddy.asm.Advice;

public class AcceptAdvice {
  @Advice.OnMethodExit
  public static void onExit(@Advice.This Object socket, @Advice.Return Object returnValue) {
    // System.out.println("Accept advice called");
    SocketInspector socketInspector = new SocketInspector();
    SocketConnection connection = socketInspector.extractSocket5Tuple(returnValue);
    Erpc erpc = new Erpc();
    erpc.sendIoctlSocketLifecycleInfo(connection, 0);
  }
}
