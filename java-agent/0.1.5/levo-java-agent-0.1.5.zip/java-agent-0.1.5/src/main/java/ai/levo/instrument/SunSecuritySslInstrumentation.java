package ai.levo.instrument;

import static net.bytebuddy.matcher.ElementMatchers.*;

import ai.levo.bootstrap.sunsecurity.SSLSocketImplAcceptAdvice;
import ai.levo.bootstrap.sunsecurity.SSLSocketImplCloseAdvice;
import ai.levo.bootstrap.sunsecurity.appinputstreamadvice.AppInputStreamAdviceReadByteArray;
import ai.levo.bootstrap.sunsecurity.appinputstreamadvice.AppInputStreamAdviceReadByteArrayOffset;
import ai.levo.bootstrap.sunsecurity.appinputstreamadvice.AppInputStreamAdviceReadNoArg;
import ai.levo.bootstrap.sunsecurity.appoutputstreamadvice.AppOutputStreamAdviceWriteByteArray;
import ai.levo.bootstrap.sunsecurity.appoutputstreamadvice.AppOutputStreamAdviceWriteByteArrayOffset;
import ai.levo.bootstrap.sunsecurity.appoutputstreamadvice.AppOutputStreamAdviceWriteInt;
import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.dynamic.ClassFileLocator;
import org.slf4j.Logger;

public class SunSecuritySslInstrumentation {

  private static final Logger logger =
      org.slf4j.LoggerFactory.getLogger(SunSecuritySslInstrumentation.class);

  public static void instrument(Instrumentation inst, ClassFileLocator bootstrapLocator)
      throws UnmodifiableClassException {
    logger.info("Instrumenting SunSecuritySslInstrumentation");

    new AgentBuilder.Default()
        .ignore(none())
        .disableClassFormatChanges()
        .with(AgentBuilder.Listener.StreamWriting.toSystemOut().withTransformationsOnly())
        .with(AgentBuilder.RedefinitionStrategy.RETRANSFORMATION)
        .with(AgentBuilder.RedefinitionStrategy.DiscoveryStrategy.Reiterating.INSTANCE)
        .with(AgentBuilder.InitializationStrategy.NoOp.INSTANCE)
        .with(AgentBuilder.TypeStrategy.Default.REDEFINE)
        .type(
            nameEndsWith("SSLSocketImpl$AppInputStream")
                .or(nameEndsWith("SSLSocketImpl$AppOutputStream"))
                .or(named("sun.security.ssl.SSLSocketImpl")))
        .transform(
            (builder1, td, cl, module, pd) ->
                builder1
                    .visit(
                        Advice.to(AppInputStreamAdviceReadNoArg.class, bootstrapLocator)
                            .on(named("read").and(takesArguments(0))))
                    .visit(
                        Advice.to(AppInputStreamAdviceReadByteArray.class, bootstrapLocator)
                            .on(
                                named("read")
                                    .and(takesArguments(1))
                                    .and(takesArgument(0, byte[].class))))
                    .visit(
                        Advice.to(AppInputStreamAdviceReadByteArrayOffset.class, bootstrapLocator)
                            .on(
                                named("read")
                                    .and(takesArguments(3))
                                    .and(takesArgument(0, byte[].class))
                                    .and(takesArgument(1, int.class))
                                    .and(takesArgument(2, int.class))))
                    .visit(
                        Advice.to(AppOutputStreamAdviceWriteInt.class, bootstrapLocator)
                            .on(
                                named("write")
                                    .and(takesArguments(1))
                                    .and(takesArgument(0, int.class))))
                    .visit(
                        Advice.to(AppOutputStreamAdviceWriteByteArray.class, bootstrapLocator)
                            .on(
                                named("write")
                                    .and(takesArguments(1))
                                    .and(takesArgument(0, byte[].class))))
                    .visit(
                        Advice.to(AppOutputStreamAdviceWriteByteArrayOffset.class, bootstrapLocator)
                            .on(
                                named("write")
                                    .and(takesArguments(3))
                                    .and(takesArgument(0, byte[].class))
                                    .and(takesArgument(1, int.class))
                                    .and(takesArgument(2, int.class))))
                    .visit(
                        Advice.to(SSLSocketImplAcceptAdvice.class, bootstrapLocator)
                            .on(named("getInputStream")))
                    .visit(
                        Advice.to(SSLSocketImplCloseAdvice.class, bootstrapLocator)
                            .on(named("close").and(takesArguments(0)))))
        .installOn(inst);
  }
}
