package ai.levo.bootstrap.sunsecurity.appinputstreamadvice;

import ai.levo.bootstrap.erpc.Erpc;
import net.bytebuddy.asm.Advice;

public class AppInputStreamAdviceReadNoArg {
  @Advice.OnMethodExit
  public static void onReadNoArg(@Advice.Return int ret) {
    if (ret >= 0) {
      // System.out.println("[levo] read(): single byte = " + ret);
      Erpc erpc = new Erpc();
      erpc.sendIoctlMessage(String.valueOf((char) ret), 2);
    }
  }
}
