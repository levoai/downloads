package ai.levo.bootstrap.model;

import java.net.InetAddress;

public class SocketConnection {
  InetAddress localAddress;
  InetAddress remoteAddress;
  int localPort;
  int remotePort;
  long threadId;
  int pid;
  byte addrFamily; // 4 -> ipv4, 6 -> ipv6

  public SocketConnection() {
    // Default constructor
    this.threadId = Thread.currentThread().getId();
  }

  public SocketConnection(
      InetAddress localAddress,
      int localPort,
      InetAddress remoteAddress,
      int remotePort,
      long threadId,
      int pid,
      byte addrFamily) {
    this.localAddress = localAddress;
    this.localPort = localPort;
    this.remoteAddress = remoteAddress;
    this.remotePort = remotePort;
    this.threadId = threadId;
    this.pid = pid;
    this.addrFamily = addrFamily;
  }

  public String getLocalAddress() {
    return localAddress != null ? localAddress.getHostAddress() : "";
  }

  public String getRemoteAddress() {
    return remoteAddress != null ? remoteAddress.getHostAddress() : "";
  }

  public int getLocalPort() {
    return localPort;
  }

  public int getRemotePort() {
    return remotePort;
  }

  public long getThreadId() {
    return threadId;
  }

  public int getPid() {
    return pid;
  }

  public byte getAddrFamily() {
    return addrFamily;
  }

  @Override
  public String toString() {
    return String.format(
        "SocketConnection{localAddress='%s', remoteAddress='%s', localPort=%d, remotePort=%d, threadId=%d, pid=%d, addrFamily=%d}",
        getLocalAddress(), getRemoteAddress(), localPort, remotePort, threadId, pid, addrFamily);
  }
}
