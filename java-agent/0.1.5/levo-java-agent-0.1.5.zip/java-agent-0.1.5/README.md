# Levo.ai Java Agent: Technical Documentation and Release Notes

## Overview
The Levo.ai Java Agent provides comprehensive traffic instrumentation for Java-based applications, enabling detailed monitoring and analysis of server and client-side spans. This document outlines the technical specifications, configuration details, and release notes for version 0.1.4 of the Levo.ai Java Agent.

## Version Information
**Current Version**: levoai-java-agent-0.1.4  
**Release Date**: October 2025

## Release Notes for Version 0.1.4

### New Features
- **TraceClientTrafficOnly Configuration**: A new configuration option, `TraceClientTrafficOnly`, has been introduced to allow selective instrumentation of client-side spans. When enabled (`TraceClientTrafficOnly=true`), the agent focuses resources on capturing outbound traffic, improving efficiency in high-traffic environments and enhancing third-party API discovery.

### Improvements
- **Optimized Traffic Instrumentation**: Previous versions (e.g., 0.1.x) captured all SSL traffic (both server and client-side) by default, which could lead to an imbalance in span collection, particularly in high-traffic scenarios. This resulted in:
  - Reduced capture rate of client spans due to resource allocation favoring server spans.
  - Occasional misses in detecting client spans.
  - Incomplete or partial data collection from client spans.
  - Potential impacts on the accuracy of third-party API discovery.
  
  The `TraceClientTrafficOnly` option addresses these challenges by allowing users to prioritize client-side traffic capture, ensuring more reliable and accurate data collection for outbound traffic without compromising server-side monitoring when not needed.

### Dependencies
- **No new dependencies** are required for upgrading to version 0.1.4.

## Installation and Upgrade Instructions

### Prerequisites
- Java Runtime Environment (JRE) or Java Development Kit (JDK) compatible with the application server.
- Application server with support for Java agent integration.
- For JRuby applications, ensure JRuby is configured to accept Java agent parameters.

### Installation Steps
1. **Download the Agent**:
   - Obtain the zipped file containing the Levo.ai Java Agent (version 0.1.4) JARs and shared library from the official Levo.ai download page: [Download Link](#).
   
2. **Deploy the Agent**:
   - Extract the zipped file and copy the agent JARs (`levo-agent-0.1.4-all.jar`) and the shared library to the application server.

3. **Configure Environment**:
   - Set the system environment variable `LIB_NATIVE_IOCTL_FILE_PATH` to the absolute path of the shared library, or pass it during program execution.

4. **Start the Application**:
   - Launch the application with the Java agent enabled by including the `-javaagent` flag with the appropriate configuration:
     ```bash
     -javaagent:/path/to/agent-jars/levo-agent-0.1.4-all.jar=JavaxSSLEngineInstrumentation=true,TraceClientTrafficOnly=true
     ```
   - For JRuby applications, configure the agent using the `JRUBY_OPTS` environment variable:
     ```bash
     JRUBY_OPTS="-J-javaagent:/path/to/agent-jars/levo-agent-0.1.4-all.jar=JavaxSSLEngineInstrumentation=true,TraceClientTrafficOnly=true"
     ```

### Upgrade Instructions
- If upgrading from an earlier version (e.g., 0.1.x):
  1. Replace the existing agent JAR file with `levo-agent-0.1.4-all.jar`.
  2. Update the shared library if provided in the new release.
  3. Restart the application with the updated `-javaagent` flag, ensuring the correct configuration options are applied.
  - **Note**: No data loss or reconfiguration is expected during the upgrade process.

## Configuration Options

### Key Configuration Parameters
- **JavaxSSLEngineInstrumentation**:
  - **Description**: Enables specific SSL engine instrumentation for compatibility with SSL traffic monitoring.
  - **Values**: `true` (default, enables SSL instrumentation) or `false` (disables SSL instrumentation).
  - **Example**: `JavaxSSLEngineInstrumentation=true`

- **TraceClientTrafficOnly**:
  - **Description**: Limits instrumentation to client-side spans, optimizing resource allocation for outbound traffic capture. When set to `false`, the agent captures both server and client-side spans.
  - **Values**: `true` (client-side only) or `false` (full traffic capture).
  - **Example**: `TraceClientTrafficOnly=true`

### Configuration Example
To enable client-only tracing with SSL instrumentation:
```bash
-javaagent:/path/to/agent-jars/levo-agent-0.1.4-all.jar=JavaxSSLEngineInstrumentation=true,TraceClientTrafficOnly=true
```

### Additional Notes
- If full traffic instrumentation (both server and client-side) is required, set `TraceClientTrafficOnly=false`.
- Ensure the `LIB_NATIVE_IOCTL_FILE_PATH` environment variable points to the correct shared library path to avoid runtime errors.

## Known Issues
- No known issues have been reported for version 0.1.4.

## Support
For further assistance, contact Levo.ai support through the official support portal or email [support@levo.ai](mailto:support@levo.ai).
