#!/usr/bin/env bash
# Part 1
# Get staged files
stagedFiles=$(git diff --staged --name-only)

# Filter for Java files
javaFiles=()
for file in $stagedFiles; do
  if [[ $file == *.java ]] && [[ -f "$file" ]]; then
    javaFiles+=("$file")
  fi
done

# Run spotlessApply only if there are Java files
if [ ${#javaFiles[@]} -gt 0 ]; then
  git stash push -k -u
  ./gradlew spotlessApply
  git stash pop
  git add "${javaFiles[@]}"
fi