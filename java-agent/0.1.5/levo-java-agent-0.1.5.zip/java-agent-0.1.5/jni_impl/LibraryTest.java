public class LibraryTest {
    public LibraryTest() {
        try {
            System.loadLibrary("native_ioctl");
            System.out.println("Library loaded successfully!");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Failed to load library: " + e.getMessage());
            System.err.println("java.library.path: " + System.getProperty("java.library.path"));
            System.exit(1);
        }
    }

    public native long testMethod();

    public static void main(String[] args) {
        System.out.println("Testing native library loading...");
        LibraryTest libraryTest = new LibraryTest();
        try {
            long result = libraryTest.testMethod();
            System.out.println("Native method call successful: " + result);
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Native method not found: " + e.getMessage());
        }
    }
}