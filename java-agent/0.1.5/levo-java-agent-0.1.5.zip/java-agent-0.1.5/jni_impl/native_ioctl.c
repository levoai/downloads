#include <jni.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>


JNIEXPORT jlong JNICALL Java_LibraryTest_testMethod(JNIEnv *env, jobject obj);
JNIEXPORT jlong JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_nativeIoctl(JNIEnv *env, jobject obj, jlong fd, jlong request, jlong arg);
JNIEXPORT jlong JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_allocateNativeMemory(JNIEnv *env, jobject obj, jlong size);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_freeNativeMemory(JNIEnv *env, jobject obj, jlong address);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeByteToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jbyte value);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeLongToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jlong value);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeIntToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jint value);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeShortToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jshort value);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeBytesToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jbyteArray data, jint start, jint length);
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_clearMemory(JNIEnv *env, jobject obj, jlong address, jlong size);
JNIEXPORT jint JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_getPid(JNIEnv *env, jobject obj);

// Native ioctl wrapper
JNIEXPORT jlong JNICALL Java_LibraryTest_testMethod(JNIEnv *env, jobject obj) {
    return 1;
}

// Native ioctl wrapper
JNIEXPORT jlong JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_nativeIoctl(JNIEnv *env, jobject obj, jlong fd, jlong request, jlong arg) {
    // Unix/Linux ioctl
    int result = ioctl((int)fd, (unsigned long)request, (void*)arg);
    return (jlong)result;
}

// Memory allocation wrapper
JNIEXPORT jlong JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_allocateNativeMemory(JNIEnv *env, jobject obj, jlong size) {
    void* memory = malloc((size_t)size);
    if (!memory) {
        return 0; // Allocation failed
    }
    return (jlong)memory;
}

// Memory deallocation wrapper
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_freeNativeMemory(JNIEnv *env, jobject obj, jlong address) {
    if (address != 0) {
        free((void*)address);
    }
}

// Write byte to memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeByteToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jbyte value) {
    if (address != 0) {
        *((char*)address + offset) = (char)value;
    }
}

// Write long to memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeLongToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jlong value) {
    if (address != 0) {
        *((long long*)((char*)address + offset)) = (long long)value;
    }
}

// Write int to memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeIntToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jint value) {
    if (address != 0) {
        *((int*)((char*)address + offset)) = (int)value;
    }
}

// Write short to memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeShortToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jshort value) {
    if (address != 0) {
        *((short*)((char*)address + offset)) = (short)value;
    }
}

// Write byte array to memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_writeBytesToMemory(JNIEnv *env, jobject obj, jlong address, jlong offset, jbyteArray data, jint start, jint length) {
    if (address != 0 && data) {
        jbyte* arrayElements = (*env)->GetByteArrayElements(env, data, NULL);
        if (arrayElements) {
            memcpy((char*)address + offset, arrayElements + start, length);
            (*env)->ReleaseByteArrayElements(env, data, arrayElements, JNI_ABORT);
        }
    }
}

// Clear memory
JNIEXPORT void JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_clearMemory(JNIEnv *env, jobject obj, jlong address, jlong size) {
    if (address != 0) {
        memset((void*)address, 0, (size_t)size);
    }
}

JNIEXPORT jint JNICALL Java_ai_levo_bootstrap_erpc_NativeIoctl_getPid(JNIEnv *env, jobject obj) {
    pid_t pid = getpid();
    return pid;
}