from bcc import BPF
import ctypes

# Target IOCTL command
IOCTL_CMD = 0xda7ad09

bpf_source = f"""
#include <uapi/linux/ptrace.h>

#define MAX_DATA_LEN 64

struct ioctl_data_t {{
    u32 pid;
    u64 addr;
    char data[MAX_DATA_LEN];
}};

BPF_PERF_OUTPUT(events);

int trace_ioctl(struct pt_regs *ctx, struct file *file, unsigned int cmd, unsigned long arg) {{
    if (cmd != {IOCTL_CMD})
        return 0;

    struct ioctl_data_t event = {{}};
    event.pid = bpf_get_current_pid_tgid() >> 32;
    event.addr = arg;

    int ret = bpf_probe_read_user(&event.data, sizeof(event.data), (void *)arg);
    bpf_trace_printk("ioctl arg: 0x%lx read_ret: %ld data: %s", arg, ret, event.data);
    events.perf_submit(ctx, &event, sizeof(event));
    return 0;
}}
"""

b = BPF(text=bpf_source)
b.attach_kprobe(event="do_vfs_ioctl", fn_name="trace_ioctl")

# Define the event struct for perf output
class IoctlData(ctypes.Structure):
    _fields_ = [
        ("pid", ctypes.c_uint32),
        ("addr", ctypes.c_uint64),
        ("data", ctypes.c_char * 64),
    ]

def print_event(cpu, data, size):
    event = ctypes.cast(data, ctypes.POINTER(IoctlData)).contents
    print(f"PID {event.pid} sent ioctl with data at 0x{event.addr:x}: {event.data[:].decode(errors='ignore')}")

print("Listening for ioctl to 0xda7ad09...")
b["events"].open_perf_buffer(print_event)

while True:
    try:
        b.perf_buffer_poll()
    except KeyboardInterrupt:
        exit()

