from bcc import BPF
import ctypes as ct
prog = """
#include <uapi/linux/ptrace.h>
#include <linux/fs.h>

// Same values as in Java code
#define IOCTL_TYPE 0xda
#define IOCTL_NR 0x7a
#define IOCTL_SIZE 64
#define EXPECTED_IOCTL ((2 << 30) | (IOCTL_TYPE << 8) | (IOCTL_NR << 0) | (IOCTL_SIZE << 16))

struct data_t {
    u32 pid;
    char comm[TASK_COMM_LEN];
    unsigned long cmd;
    char buffer[32768];
};

BPF_PERF_OUTPUT(events);

int kprobe__do_vfs_ioctl(struct pt_regs *ctx) {
    u32 cmd = PT_REGS_PARM3(ctx);
    u64 pid = bpf_get_current_pid_tgid() >> 32;
    //void *arg = (void *)CTX_PARM4(ctx);
    u64 *arg = (u64 *)PT_REGS_PARM4(ctx);
    if (cmd != EXPECTED_IOCTL)
        return 0;

    // Debug output
    bpf_trace_printk("ioctl called: cmd=0x%lx, expected=0x%lx\\n", cmd, EXPECTED_IOCTL);
    
    struct data_t data = {};
    data.pid = pid;
    bpf_get_current_comm(&data.comm, sizeof(data.comm));
    data.cmd = cmd;

    if(arg) {
      int err = bpf_probe_read_user(&data.buffer, sizeof(data.buffer), (void *)arg);
      bpf_trace_printk("Error: %d\\n", err);
    }
    bpf_trace_printk("event submit 0x%lx\\n", cmd, EXPECTED_IOCTL);
    int err = events.perf_submit(ctx, &data, sizeof(data));
    bpf_trace_printk("Error: %d\\n", err);
    return 0;
}
"""

b = BPF(text=prog)

class Data(ct.Structure):
    _fields_ = [
        ("pid", ct.c_uint32),
        ("comm", ct.c_char * 16),
        ("cmd", ct.c_ulong),
        ("buffer", ct.c_char * 64)
    ]

def print_event(cpu, data, size):
    event = ct.cast(data, ct.POINTER(Data)).contents
    print(f"\n=== IOCTL Captured ===")
    print(f"PID: {event.pid}")
    print(f"Command: {event.comm.decode('utf-8')}")
    print(f"IOCTL: 0x{event.cmd:x}")
    buffer_str = bytes(event.buffer).decode('utf-8').rstrip('\x00')
    print(f"Buffer: {buffer_str}")
    print("===================\n")

# Set up perf buffer with page count
b["events"].open_perf_buffer(print_event, page_cnt=64)

print("Starting tracing... Hit Ctrl+C to exit")
while True:
    try:
        # Add a small timeout to prevent CPU spin
        b.perf_buffer_poll(timeout=100)
    except KeyboardInterrupt:
        break
    except Exception as e:
        print(f"Error: {e}")
        continue
