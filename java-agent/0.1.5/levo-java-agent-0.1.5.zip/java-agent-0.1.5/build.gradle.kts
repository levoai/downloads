plugins {
    id("java")
    id("com.github.johnrengelman.shadow") version "8.1.1"
    id("com.diffplug.spotless") version "5.14.3"
}

group = project.group
version = project.version


repositories {
    mavenCentral()
}

dependencies {
    implementation("net.bytebuddy:byte-buddy:1.14.11")
    implementation("net.bytebuddy:byte-buddy-agent:1.14.11")
    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")
    implementation("org.slf4j:slf4j-api:2.0.17")
    runtimeOnly("ch.qos.logback:logback-classic:1.3.15")
}

spotless {
    java {
        googleJavaFormat("1.7")
        removeUnusedImports()
    }
}


val bootstrapJar by tasks.creating(Jar::class) {
    archiveBaseName.set("levo-agent-bootstrap")
    from(sourceSets["main"].output) {
        include("ai/levo/bootstrap/**")
    }
    exclude("ai/levo/agent/**", "ai/levo/instrument/**")
    manifest {
        attributes["Created-By"] = "Gradle"
    }
    destinationDirectory.set(file("${project.rootDir}/build/libs"))
    from(configurations.runtimeClasspath.get().filter {
        it.name.contains("byte-buddy")
    }.map { zipTree(it) }) {
        include("net/bytebuddy/**")
    }
}

tasks.shadowJar {
    archiveBaseName.set("levo-agent")
    manifest {
        attributes(
                "Premain-Class" to "ai.levo.agent.Agent",
                "Agent-Class" to "ai.levo.agent.Agent",
                "Can-Redefine-Classes" to "true",
                "Can-Retransform-Classes" to "true"
        )
    }
    exclude("ai/levo/bootstrap/**")
    dependsOn(bootstrapJar)
}

// Make build depend on shadowJar
tasks.build {
    dependsOn(tasks.shadowJar)
}

tasks.test {
    useJUnitPlatform()
}

tasks.register<Copy>("updateGitHooks") {
    File("${project.rootDir}/scripts/pre-commit.sh").copyTo(File("${project.rootDir}/.git/hooks/pre-commit"), true)
    File("${project.rootDir}/.git/hooks/pre-commit.sh").setExecutable(true)
}

tasks.withType<JavaCompile> {
    dependsOn("updateGitHooks")
}
