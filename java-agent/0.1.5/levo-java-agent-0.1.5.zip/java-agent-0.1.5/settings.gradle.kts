rootProject.name = "levoai-java-agent"
